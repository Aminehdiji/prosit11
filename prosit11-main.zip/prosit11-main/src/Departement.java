public class Departement {
    private String name;

    public Departement(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
